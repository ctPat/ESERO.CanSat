﻿
using System;

namespace ESERO.CanSat
{
    partial class fMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
            Syncfusion.Windows.Forms.Tools.ActiveStateCollection activeStateCollection1 = new Syncfusion.Windows.Forms.Tools.ActiveStateCollection();
            Syncfusion.Windows.Forms.Tools.InactiveStateCollection inactiveStateCollection1 = new Syncfusion.Windows.Forms.Tools.InactiveStateCollection();
            Syncfusion.Windows.Forms.Tools.SliderCollection sliderCollection1 = new Syncfusion.Windows.Forms.Tools.SliderCollection();
            Syncfusion.Windows.Forms.Tools.ActiveStateCollection activeStateCollection2 = new Syncfusion.Windows.Forms.Tools.ActiveStateCollection();
            Syncfusion.Windows.Forms.Tools.InactiveStateCollection inactiveStateCollection2 = new Syncfusion.Windows.Forms.Tools.InactiveStateCollection();
            Syncfusion.Windows.Forms.Tools.SliderCollection sliderCollection2 = new Syncfusion.Windows.Forms.Tools.SliderCollection();
            Syncfusion.Windows.Forms.Tools.ActiveStateCollection activeStateCollection3 = new Syncfusion.Windows.Forms.Tools.ActiveStateCollection();
            Syncfusion.Windows.Forms.Tools.InactiveStateCollection inactiveStateCollection3 = new Syncfusion.Windows.Forms.Tools.InactiveStateCollection();
            Syncfusion.Windows.Forms.Tools.SliderCollection sliderCollection3 = new Syncfusion.Windows.Forms.Tools.SliderCollection();
            Syncfusion.Windows.Forms.Tools.ActiveStateCollection activeStateCollection4 = new Syncfusion.Windows.Forms.Tools.ActiveStateCollection();
            Syncfusion.Windows.Forms.Tools.InactiveStateCollection inactiveStateCollection4 = new Syncfusion.Windows.Forms.Tools.InactiveStateCollection();
            Syncfusion.Windows.Forms.Tools.SliderCollection sliderCollection4 = new Syncfusion.Windows.Forms.Tools.SliderCollection();
            Syncfusion.Windows.Forms.Tools.ActiveStateCollection activeStateCollection5 = new Syncfusion.Windows.Forms.Tools.ActiveStateCollection();
            Syncfusion.Windows.Forms.Tools.InactiveStateCollection inactiveStateCollection5 = new Syncfusion.Windows.Forms.Tools.InactiveStateCollection();
            Syncfusion.Windows.Forms.Tools.SliderCollection sliderCollection5 = new Syncfusion.Windows.Forms.Tools.SliderCollection();
            Syncfusion.Windows.Forms.Tools.ActiveStateCollection activeStateCollection6 = new Syncfusion.Windows.Forms.Tools.ActiveStateCollection();
            Syncfusion.Windows.Forms.Tools.InactiveStateCollection inactiveStateCollection6 = new Syncfusion.Windows.Forms.Tools.InactiveStateCollection();
            Syncfusion.Windows.Forms.Tools.SliderCollection sliderCollection6 = new Syncfusion.Windows.Forms.Tools.SliderCollection();
            Syncfusion.Windows.Forms.Tools.ActiveStateCollection activeStateCollection7 = new Syncfusion.Windows.Forms.Tools.ActiveStateCollection();
            Syncfusion.Windows.Forms.Tools.InactiveStateCollection inactiveStateCollection7 = new Syncfusion.Windows.Forms.Tools.InactiveStateCollection();
            Syncfusion.Windows.Forms.Tools.SliderCollection sliderCollection7 = new Syncfusion.Windows.Forms.Tools.SliderCollection();
            Syncfusion.Windows.Forms.Tools.ActiveStateCollection activeStateCollection8 = new Syncfusion.Windows.Forms.Tools.ActiveStateCollection();
            Syncfusion.Windows.Forms.Tools.InactiveStateCollection inactiveStateCollection8 = new Syncfusion.Windows.Forms.Tools.InactiveStateCollection();
            Syncfusion.Windows.Forms.Tools.SliderCollection sliderCollection8 = new Syncfusion.Windows.Forms.Tools.SliderCollection();
            Syncfusion.Windows.Forms.Tools.ActiveStateCollection activeStateCollection9 = new Syncfusion.Windows.Forms.Tools.ActiveStateCollection();
            Syncfusion.Windows.Forms.Tools.InactiveStateCollection inactiveStateCollection9 = new Syncfusion.Windows.Forms.Tools.InactiveStateCollection();
            Syncfusion.Windows.Forms.Tools.SliderCollection sliderCollection9 = new Syncfusion.Windows.Forms.Tools.SliderCollection();
            Syncfusion.Windows.Forms.Tools.ActiveStateCollection activeStateCollection10 = new Syncfusion.Windows.Forms.Tools.ActiveStateCollection();
            Syncfusion.Windows.Forms.Tools.InactiveStateCollection inactiveStateCollection10 = new Syncfusion.Windows.Forms.Tools.InactiveStateCollection();
            Syncfusion.Windows.Forms.Tools.SliderCollection sliderCollection10 = new Syncfusion.Windows.Forms.Tools.SliderCollection();
            Syncfusion.Windows.Forms.Tools.ActiveStateCollection activeStateCollection11 = new Syncfusion.Windows.Forms.Tools.ActiveStateCollection();
            Syncfusion.Windows.Forms.Tools.InactiveStateCollection inactiveStateCollection11 = new Syncfusion.Windows.Forms.Tools.InactiveStateCollection();
            Syncfusion.Windows.Forms.Tools.SliderCollection sliderCollection11 = new Syncfusion.Windows.Forms.Tools.SliderCollection();
            Syncfusion.Windows.Forms.Tools.ActiveStateCollection activeStateCollection12 = new Syncfusion.Windows.Forms.Tools.ActiveStateCollection();
            Syncfusion.Windows.Forms.Tools.InactiveStateCollection inactiveStateCollection12 = new Syncfusion.Windows.Forms.Tools.InactiveStateCollection();
            Syncfusion.Windows.Forms.Tools.SliderCollection sliderCollection12 = new Syncfusion.Windows.Forms.Tools.SliderCollection();
            Syncfusion.Windows.Forms.Tools.ActiveStateCollection activeStateCollection13 = new Syncfusion.Windows.Forms.Tools.ActiveStateCollection();
            Syncfusion.Windows.Forms.Tools.InactiveStateCollection inactiveStateCollection13 = new Syncfusion.Windows.Forms.Tools.InactiveStateCollection();
            Syncfusion.Windows.Forms.Tools.SliderCollection sliderCollection13 = new Syncfusion.Windows.Forms.Tools.SliderCollection();
            Syncfusion.Windows.Forms.Tools.ActiveStateCollection activeStateCollection14 = new Syncfusion.Windows.Forms.Tools.ActiveStateCollection();
            Syncfusion.Windows.Forms.Tools.InactiveStateCollection inactiveStateCollection14 = new Syncfusion.Windows.Forms.Tools.InactiveStateCollection();
            Syncfusion.Windows.Forms.Tools.SliderCollection sliderCollection14 = new Syncfusion.Windows.Forms.Tools.SliderCollection();
            this.btnOpenPort = new Syncfusion.Windows.Forms.Tools.toolstripitem();
            this.btnViewTraffic = new Syncfusion.Windows.Forms.Tools.toolstripitem();
            this.pnlMenu = new Syncfusion.Windows.Forms.Tools.GradientPanel();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnGraphs = new System.Windows.Forms.Button();
            this.picE = new System.Windows.Forms.PictureBox();
            this.btnAbout = new System.Windows.Forms.Button();
            this.picD = new System.Windows.Forms.PictureBox();
            this.btnSelectChannels = new System.Windows.Forms.Button();
            this.picC = new System.Windows.Forms.PictureBox();
            this.btnSerialPort = new System.Windows.Forms.Button();
            this.picB = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.picA = new System.Windows.Forms.PictureBox();
            this.pbxTop = new System.Windows.Forms.PictureBox();
            this.pnlB = new Syncfusion.Windows.Forms.Tools.GradientPanel();
            this.grpData5 = new System.Windows.Forms.GroupBox();
            this.glbl13 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.glbl14 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.lblCh13 = new System.Windows.Forms.Label();
            this.lblCh14 = new System.Windows.Forms.Label();
            this.lblDim13 = new System.Windows.Forms.Label();
            this.lblDim14 = new System.Windows.Forms.Label();
            this.lblCh7 = new System.Windows.Forms.Label();
            this.lblCh6 = new System.Windows.Forms.Label();
            this.lblCh5 = new System.Windows.Forms.Label();
            this.lblCh4 = new System.Windows.Forms.Label();
            this.lblCh3 = new System.Windows.Forms.Label();
            this.lblDim7 = new System.Windows.Forms.Label();
            this.lblDim6 = new System.Windows.Forms.Label();
            this.lblDim12 = new System.Windows.Forms.Label();
            this.lblDim5 = new System.Windows.Forms.Label();
            this.lblDim11 = new System.Windows.Forms.Label();
            this.lblDim10 = new System.Windows.Forms.Label();
            this.lblDim4 = new System.Windows.Forms.Label();
            this.lblDim9 = new System.Windows.Forms.Label();
            this.lblDim3 = new System.Windows.Forms.Label();
            this.lblDim8 = new System.Windows.Forms.Label();
            this.lblDim2 = new System.Windows.Forms.Label();
            this.lblDim15 = new System.Windows.Forms.Label();
            this.lblDim1 = new System.Windows.Forms.Label();
            this.lblCh15 = new System.Windows.Forms.Label();
            this.lblCh1 = new System.Windows.Forms.Label();
            this.lblCh2 = new System.Windows.Forms.Label();
            this.lblCh12 = new System.Windows.Forms.Label();
            this.lblCh11 = new System.Windows.Forms.Label();
            this.lblCh10 = new System.Windows.Forms.Label();
            this.lblCh9 = new System.Windows.Forms.Label();
            this.lblCh8 = new System.Windows.Forms.Label();
            this.lblRecording = new System.Windows.Forms.Label();
            this.picRecord = new System.Windows.Forms.PictureBox();
            this.chkAll = new Syncfusion.Windows.Forms.Tools.CheckBoxAdv();
            this.glbl7 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.glbl6 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.glbl12 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.glbl5 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.glbl11 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.glbl4 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.glbl10 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.glbl3 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.glbl9 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.glbl8 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.glbl2 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.glbl15 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.glbl1 = new Syncfusion.Windows.Forms.Tools.GradientLabel();
            this.tgl6 = new Syncfusion.Windows.Forms.Tools.ToggleButton();
            this.grpData4 = new System.Windows.Forms.GroupBox();
            this.autoLabel15 = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            this.autoLabel16 = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            this.tgl14 = new Syncfusion.Windows.Forms.Tools.ToggleButton();
            this.tgl13 = new Syncfusion.Windows.Forms.Tools.ToggleButton();
            this.grpData3 = new System.Windows.Forms.GroupBox();
            this.tgl11 = new Syncfusion.Windows.Forms.Tools.ToggleButton();
            this.tgl10 = new Syncfusion.Windows.Forms.Tools.ToggleButton();
            this.tgl12 = new Syncfusion.Windows.Forms.Tools.ToggleButton();
            this.tgl9 = new Syncfusion.Windows.Forms.Tools.ToggleButton();
            this.autoLabel9 = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            this.autoLabel10 = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            this.autoLabel11 = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            this.autoLabel12 = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            this.grpData2 = new System.Windows.Forms.GroupBox();
            this.tgl8 = new Syncfusion.Windows.Forms.Tools.ToggleButton();
            this.tgl5 = new Syncfusion.Windows.Forms.Tools.ToggleButton();
            this.tgl7 = new Syncfusion.Windows.Forms.Tools.ToggleButton();
            this.autoLabel5 = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            this.autoLabel6 = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            this.autoLabel7 = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            this.autoLabel8 = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            this.grpData1 = new System.Windows.Forms.GroupBox();
            this.tgl2 = new Syncfusion.Windows.Forms.Tools.ToggleButton();
            this.tgl4 = new Syncfusion.Windows.Forms.Tools.ToggleButton();
            this.tgl3 = new Syncfusion.Windows.Forms.Tools.ToggleButton();
            this.tgl1 = new Syncfusion.Windows.Forms.Tools.ToggleButton();
            this.autoLabel4 = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            this.autoLabel3 = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            this.autoLabel2 = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            this.autoLabel1 = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            this.pnlA = new Syncfusion.Windows.Forms.Tools.GradientPanel();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.txtSpeed = new Syncfusion.Windows.Forms.Tools.TextBoxExt();
            this.txtPortAttributes = new Syncfusion.Windows.Forms.Tools.TextBoxExt();
            this.txtRawData = new Syncfusion.Windows.Forms.Tools.TextBoxExt();
            this.txtVersion = new Syncfusion.Windows.Forms.Tools.TextBoxExt();
            this.txtConnected = new Syncfusion.Windows.Forms.Tools.TextBoxExt();
            this.pnlC = new Syncfusion.Windows.Forms.Tools.GradientPanel();
            this.ttMain = new Syncfusion.Windows.Forms.SfToolTip(this.components);
            this.dlgOpenFile = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.pnlMenu)).BeginInit();
            this.pnlMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlB)).BeginInit();
            this.pnlB.SuspendLayout();
            this.grpData5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRecord)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAll)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl6)).BeginInit();
            this.grpData4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tgl14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl13)).BeginInit();
            this.grpData3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tgl11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl9)).BeginInit();
            this.grpData2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tgl8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl7)).BeginInit();
            this.grpData1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tgl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlA)).BeginInit();
            this.pnlA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSpeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPortAttributes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRawData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVersion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtConnected)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlC)).BeginInit();
            this.SuspendLayout();
            // 
            // btnOpenPort
            // 
            this.btnOpenPort.Image = ((System.Drawing.Image)(resources.GetObject("btnOpenPort.Image")));
            this.btnOpenPort.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOpenPort.Name = "btnOpenPort";
            this.btnOpenPort.Size = new System.Drawing.Size(23, 23);
            this.btnOpenPort.Text = "Let\'s begin";
            // 
            // btnViewTraffic
            // 
            this.btnViewTraffic.Image = ((System.Drawing.Image)(resources.GetObject("btnViewTraffic.Image")));
            this.btnViewTraffic.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnViewTraffic.Name = "btnViewTraffic";
            this.btnViewTraffic.Size = new System.Drawing.Size(23, 23);
            this.btnViewTraffic.Text = "View the traffic";
            // 
            // pnlMenu
            // 
            this.pnlMenu.BackColor = System.Drawing.Color.White;
            this.pnlMenu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pnlMenu.Controls.Add(this.btnExport);
            this.pnlMenu.Controls.Add(this.btnGraphs);
            this.pnlMenu.Controls.Add(this.picE);
            this.pnlMenu.Controls.Add(this.btnAbout);
            this.pnlMenu.Controls.Add(this.picD);
            this.pnlMenu.Controls.Add(this.btnSelectChannels);
            this.pnlMenu.Controls.Add(this.picC);
            this.pnlMenu.Controls.Add(this.btnSerialPort);
            this.pnlMenu.Controls.Add(this.picB);
            this.pnlMenu.Controls.Add(this.pictureBox2);
            this.pnlMenu.Controls.Add(this.picA);
            this.pnlMenu.Controls.Add(this.pbxTop);
            this.pnlMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlMenu.Location = new System.Drawing.Point(0, 0);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.Size = new System.Drawing.Size(196, 532);
            this.pnlMenu.TabIndex = 2;
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.btnExport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExport.Enabled = false;
            this.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExport.ForeColor = System.Drawing.Color.White;
            this.btnExport.Location = new System.Drawing.Point(62, 288);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(127, 47);
            this.btnExport.TabIndex = 9;
            this.btnExport.Text = "Analyse in Excel";
            this.ttMain.SetToolTip(this.btnExport, "Open exported files in Excel");
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // btnGraphs
            // 
            this.btnGraphs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.btnGraphs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGraphs.Enabled = false;
            this.btnGraphs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGraphs.ForeColor = System.Drawing.Color.White;
            this.btnGraphs.Location = new System.Drawing.Point(62, 235);
            this.btnGraphs.Name = "btnGraphs";
            this.btnGraphs.Size = new System.Drawing.Size(127, 47);
            this.btnGraphs.TabIndex = 9;
            this.btnGraphs.Text = "Visualisation";
            this.ttMain.SetToolTip(this.btnGraphs, "Visualise the data");
            this.btnGraphs.UseVisualStyleBackColor = false;
            this.btnGraphs.Click += new System.EventHandler(this.btnGraphs_Click);
            // 
            // picE
            // 
            this.picE.Image = ((System.Drawing.Image)(resources.GetObject("picE.Image")));
            this.picE.Location = new System.Drawing.Point(3, 288);
            this.picE.Name = "picE";
            this.picE.Size = new System.Drawing.Size(53, 47);
            this.picE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picE.TabIndex = 8;
            this.picE.TabStop = false;
            // 
            // btnAbout
            // 
            this.btnAbout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.btnAbout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAbout.ForeColor = System.Drawing.Color.White;
            this.btnAbout.Location = new System.Drawing.Point(62, 341);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(127, 47);
            this.btnAbout.TabIndex = 9;
            this.btnAbout.Text = "About";
            this.ttMain.SetToolTip(this.btnAbout, "Team members");
            this.btnAbout.UseVisualStyleBackColor = false;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // picD
            // 
            this.picD.Image = ((System.Drawing.Image)(resources.GetObject("picD.Image")));
            this.picD.Location = new System.Drawing.Point(3, 235);
            this.picD.Name = "picD";
            this.picD.Size = new System.Drawing.Size(53, 47);
            this.picD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picD.TabIndex = 8;
            this.picD.TabStop = false;
            // 
            // btnSelectChannels
            // 
            this.btnSelectChannels.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.btnSelectChannels.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSelectChannels.Enabled = false;
            this.btnSelectChannels.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectChannels.ForeColor = System.Drawing.Color.White;
            this.btnSelectChannels.Location = new System.Drawing.Point(62, 182);
            this.btnSelectChannels.Name = "btnSelectChannels";
            this.btnSelectChannels.Size = new System.Drawing.Size(127, 47);
            this.btnSelectChannels.TabIndex = 9;
            this.btnSelectChannels.Text = "Channels and Live Data";
            this.ttMain.SetToolTip(this.btnSelectChannels, "Select the channel values you require");
            this.btnSelectChannels.UseVisualStyleBackColor = false;
            this.btnSelectChannels.Click += new System.EventHandler(this.btnSelectChannels_Click);
            // 
            // picC
            // 
            this.picC.Image = ((System.Drawing.Image)(resources.GetObject("picC.Image")));
            this.picC.Location = new System.Drawing.Point(3, 341);
            this.picC.Name = "picC";
            this.picC.Size = new System.Drawing.Size(53, 47);
            this.picC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picC.TabIndex = 8;
            this.picC.TabStop = false;
            // 
            // btnSerialPort
            // 
            this.btnSerialPort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.btnSerialPort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSerialPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSerialPort.ForeColor = System.Drawing.Color.White;
            this.btnSerialPort.Location = new System.Drawing.Point(62, 129);
            this.btnSerialPort.Name = "btnSerialPort";
            this.btnSerialPort.Size = new System.Drawing.Size(127, 47);
            this.btnSerialPort.TabIndex = 9;
            this.btnSerialPort.Text = "Connection Details";
            this.ttMain.SetToolTip(this.btnSerialPort, "View the connection details");
            this.btnSerialPort.UseVisualStyleBackColor = false;
            this.btnSerialPort.Click += new System.EventHandler(this.btnSerialPort_Click);
            // 
            // picB
            // 
            this.picB.Image = ((System.Drawing.Image)(resources.GetObject("picB.Image")));
            this.picB.Location = new System.Drawing.Point(3, 182);
            this.picB.Name = "picB";
            this.picB.Size = new System.Drawing.Size(53, 47);
            this.picB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picB.TabIndex = 8;
            this.picB.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 409);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(196, 123);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // picA
            // 
            this.picA.Image = ((System.Drawing.Image)(resources.GetObject("picA.Image")));
            this.picA.Location = new System.Drawing.Point(3, 129);
            this.picA.Name = "picA";
            this.picA.Size = new System.Drawing.Size(53, 47);
            this.picA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picA.TabIndex = 5;
            this.picA.TabStop = false;
            // 
            // pbxTop
            // 
            this.pbxTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pbxTop.Image = ((System.Drawing.Image)(resources.GetObject("pbxTop.Image")));
            this.pbxTop.Location = new System.Drawing.Point(0, 0);
            this.pbxTop.Name = "pbxTop";
            this.pbxTop.Size = new System.Drawing.Size(196, 123);
            this.pbxTop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxTop.TabIndex = 4;
            this.pbxTop.TabStop = false;
            // 
            // pnlB
            // 
            this.pnlB.BackColor = System.Drawing.Color.White;
            this.pnlB.Border3DStyle = System.Windows.Forms.Border3DStyle.Flat;
            this.pnlB.BorderColor = System.Drawing.Color.Transparent;
            this.pnlB.BorderSingle = System.Windows.Forms.ButtonBorderStyle.None;
            this.pnlB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pnlB.Controls.Add(this.grpData5);
            this.pnlB.Controls.Add(this.lblCh7);
            this.pnlB.Controls.Add(this.lblCh6);
            this.pnlB.Controls.Add(this.lblCh5);
            this.pnlB.Controls.Add(this.lblCh4);
            this.pnlB.Controls.Add(this.lblCh3);
            this.pnlB.Controls.Add(this.lblDim7);
            this.pnlB.Controls.Add(this.lblDim6);
            this.pnlB.Controls.Add(this.lblDim12);
            this.pnlB.Controls.Add(this.lblDim5);
            this.pnlB.Controls.Add(this.lblDim11);
            this.pnlB.Controls.Add(this.lblDim10);
            this.pnlB.Controls.Add(this.lblDim4);
            this.pnlB.Controls.Add(this.lblDim9);
            this.pnlB.Controls.Add(this.lblDim3);
            this.pnlB.Controls.Add(this.lblDim8);
            this.pnlB.Controls.Add(this.lblDim2);
            this.pnlB.Controls.Add(this.lblDim15);
            this.pnlB.Controls.Add(this.lblDim1);
            this.pnlB.Controls.Add(this.lblCh15);
            this.pnlB.Controls.Add(this.lblCh1);
            this.pnlB.Controls.Add(this.lblCh2);
            this.pnlB.Controls.Add(this.lblCh12);
            this.pnlB.Controls.Add(this.lblCh11);
            this.pnlB.Controls.Add(this.lblCh10);
            this.pnlB.Controls.Add(this.lblCh9);
            this.pnlB.Controls.Add(this.lblCh8);
            this.pnlB.Controls.Add(this.lblRecording);
            this.pnlB.Controls.Add(this.picRecord);
            this.pnlB.Controls.Add(this.chkAll);
            this.pnlB.Controls.Add(this.glbl7);
            this.pnlB.Controls.Add(this.glbl6);
            this.pnlB.Controls.Add(this.glbl12);
            this.pnlB.Controls.Add(this.glbl5);
            this.pnlB.Controls.Add(this.glbl11);
            this.pnlB.Controls.Add(this.glbl4);
            this.pnlB.Controls.Add(this.glbl10);
            this.pnlB.Controls.Add(this.glbl3);
            this.pnlB.Controls.Add(this.glbl9);
            this.pnlB.Controls.Add(this.glbl8);
            this.pnlB.Controls.Add(this.glbl2);
            this.pnlB.Controls.Add(this.glbl15);
            this.pnlB.Controls.Add(this.glbl1);
            this.pnlB.Controls.Add(this.tgl6);
            this.pnlB.Controls.Add(this.grpData4);
            this.pnlB.Controls.Add(this.grpData3);
            this.pnlB.Controls.Add(this.grpData2);
            this.pnlB.Controls.Add(this.grpData1);
            this.pnlB.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlB.Location = new System.Drawing.Point(196, 0);
            this.pnlB.Name = "pnlB";
            this.pnlB.Size = new System.Drawing.Size(829, 532);
            this.pnlB.TabIndex = 3;
            this.pnlB.Visible = false;
            // 
            // grpData5
            // 
            this.grpData5.BackColor = System.Drawing.Color.White;
            this.grpData5.Controls.Add(this.glbl13);
            this.grpData5.Controls.Add(this.glbl14);
            this.grpData5.Controls.Add(this.lblCh13);
            this.grpData5.Controls.Add(this.lblCh14);
            this.grpData5.Controls.Add(this.lblDim13);
            this.grpData5.Controls.Add(this.lblDim14);
            this.grpData5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.grpData5.ForeColor = System.Drawing.Color.Blue;
            this.grpData5.Location = new System.Drawing.Point(496, 379);
            this.grpData5.Name = "grpData5";
            this.grpData5.Size = new System.Drawing.Size(292, 93);
            this.grpData5.TabIndex = 13;
            this.grpData5.TabStop = false;
            // 
            // glbl13
            // 
            this.glbl13.BeforeTouchSize = new System.Drawing.Size(102, 24);
            this.glbl13.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl13.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.glbl13.ForeColor = System.Drawing.Color.Black;
            this.glbl13.Location = new System.Drawing.Point(121, 17);
            this.glbl13.Name = "glbl13";
            this.glbl13.Size = new System.Drawing.Size(102, 24);
            this.glbl13.TabIndex = 7;
            this.glbl13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // glbl14
            // 
            this.glbl14.BeforeTouchSize = new System.Drawing.Size(102, 24);
            this.glbl14.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl14.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.glbl14.ForeColor = System.Drawing.Color.Black;
            this.glbl14.Location = new System.Drawing.Point(121, 55);
            this.glbl14.Name = "glbl14";
            this.glbl14.Size = new System.Drawing.Size(102, 24);
            this.glbl14.TabIndex = 7;
            this.glbl14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCh13
            // 
            this.lblCh13.AutoSize = true;
            this.lblCh13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblCh13.ForeColor = System.Drawing.Color.Black;
            this.lblCh13.Location = new System.Drawing.Point(58, 17);
            this.lblCh13.Name = "lblCh13";
            this.lblCh13.Size = new System.Drawing.Size(42, 15);
            this.lblCh13.TabIndex = 12;
            this.lblCh13.Text = "Touch:";
            // 
            // lblCh14
            // 
            this.lblCh14.AutoSize = true;
            this.lblCh14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblCh14.ForeColor = System.Drawing.Color.Black;
            this.lblCh14.Location = new System.Drawing.Point(56, 55);
            this.lblCh14.Name = "lblCh14";
            this.lblCh14.Size = new System.Drawing.Size(44, 15);
            this.lblCh14.TabIndex = 12;
            this.lblCh14.Text = "Sound:";
            // 
            // lblDim13
            // 
            this.lblDim13.AutoSize = true;
            this.lblDim13.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim13.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim13.Location = new System.Drawing.Point(239, 15);
            this.lblDim13.Name = "lblDim13";
            this.lblDim13.Size = new System.Drawing.Size(50, 17);
            this.lblDim13.TabIndex = 12;
            this.lblDim13.Text = "Yes/No";
            // 
            // lblDim14
            // 
            this.lblDim14.AutoSize = true;
            this.lblDim14.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim14.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim14.Location = new System.Drawing.Point(239, 52);
            this.lblDim14.Name = "lblDim14";
            this.lblDim14.Size = new System.Drawing.Size(51, 17);
            this.lblDim14.TabIndex = 12;
            this.lblDim14.Text = "Decibel";
            // 
            // lblCh7
            // 
            this.lblCh7.AutoSize = true;
            this.lblCh7.Location = new System.Drawing.Point(241, 424);
            this.lblCh7.Name = "lblCh7";
            this.lblCh7.Size = new System.Drawing.Size(75, 15);
            this.lblCh7.TabIndex = 12;
            this.lblCh7.Text = "Accel - Z Dir:";
            // 
            // lblCh6
            // 
            this.lblCh6.AutoSize = true;
            this.lblCh6.Location = new System.Drawing.Point(241, 387);
            this.lblCh6.Name = "lblCh6";
            this.lblCh6.Size = new System.Drawing.Size(75, 15);
            this.lblCh6.TabIndex = 12;
            this.lblCh6.Text = "Accel - Y Dir:";
            // 
            // lblCh5
            // 
            this.lblCh5.AutoSize = true;
            this.lblCh5.Location = new System.Drawing.Point(241, 350);
            this.lblCh5.Name = "lblCh5";
            this.lblCh5.Size = new System.Drawing.Size(75, 15);
            this.lblCh5.TabIndex = 12;
            this.lblCh5.Text = "Accel - X Dir:";
            // 
            // lblCh4
            // 
            this.lblCh4.AutoSize = true;
            this.lblCh4.Location = new System.Drawing.Point(252, 313);
            this.lblCh4.Name = "lblCh4";
            this.lblCh4.Size = new System.Drawing.Size(64, 15);
            this.lblCh4.TabIndex = 12;
            this.lblCh4.Text = "Temp - Int:";
            // 
            // lblCh3
            // 
            this.lblCh3.AutoSize = true;
            this.lblCh3.Location = new System.Drawing.Point(264, 276);
            this.lblCh3.Name = "lblCh3";
            this.lblCh3.Size = new System.Drawing.Size(52, 15);
            this.lblCh3.TabIndex = 12;
            this.lblCh3.Text = "Altitude:";
            // 
            // lblDim7
            // 
            this.lblDim7.AutoSize = true;
            this.lblDim7.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim7.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim7.Location = new System.Drawing.Point(440, 427);
            this.lblDim7.Name = "lblDim7";
            this.lblDim7.Size = new System.Drawing.Size(43, 17);
            this.lblDim7.TabIndex = 12;
            this.lblDim7.Text = "Milli-g";
            // 
            // lblDim6
            // 
            this.lblDim6.AutoSize = true;
            this.lblDim6.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim6.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim6.Location = new System.Drawing.Point(440, 390);
            this.lblDim6.Name = "lblDim6";
            this.lblDim6.Size = new System.Drawing.Size(43, 17);
            this.lblDim6.TabIndex = 12;
            this.lblDim6.Text = "Milli-g";
            // 
            // lblDim12
            // 
            this.lblDim12.AutoSize = true;
            this.lblDim12.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim12.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim12.Location = new System.Drawing.Point(735, 351);
            this.lblDim12.Name = "lblDim12";
            this.lblDim12.Size = new System.Drawing.Size(53, 17);
            this.lblDim12.TabIndex = 12;
            this.lblDim12.Text = "Micro-T";
            // 
            // lblDim5
            // 
            this.lblDim5.AutoSize = true;
            this.lblDim5.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim5.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim5.Location = new System.Drawing.Point(440, 353);
            this.lblDim5.Name = "lblDim5";
            this.lblDim5.Size = new System.Drawing.Size(43, 17);
            this.lblDim5.TabIndex = 12;
            this.lblDim5.Text = "Milli-g";
            // 
            // lblDim11
            // 
            this.lblDim11.AutoSize = true;
            this.lblDim11.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim11.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim11.Location = new System.Drawing.Point(735, 314);
            this.lblDim11.Name = "lblDim11";
            this.lblDim11.Size = new System.Drawing.Size(31, 17);
            this.lblDim11.TabIndex = 12;
            this.lblDim11.Text = "Deg";
            // 
            // lblDim10
            // 
            this.lblDim10.AutoSize = true;
            this.lblDim10.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim10.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim10.Location = new System.Drawing.Point(735, 277);
            this.lblDim10.Name = "lblDim10";
            this.lblDim10.Size = new System.Drawing.Size(31, 17);
            this.lblDim10.TabIndex = 12;
            this.lblDim10.Text = "Deg";
            // 
            // lblDim4
            // 
            this.lblDim4.AutoSize = true;
            this.lblDim4.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim4.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim4.Location = new System.Drawing.Point(440, 316);
            this.lblDim4.Name = "lblDim4";
            this.lblDim4.Size = new System.Drawing.Size(20, 17);
            this.lblDim4.TabIndex = 12;
            this.lblDim4.Text = "°C";
            // 
            // lblDim9
            // 
            this.lblDim9.AutoSize = true;
            this.lblDim9.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim9.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim9.Location = new System.Drawing.Point(735, 240);
            this.lblDim9.Name = "lblDim9";
            this.lblDim9.Size = new System.Drawing.Size(45, 17);
            this.lblDim9.TabIndex = 12;
            this.lblDim9.Text = "W/m2";
            // 
            // lblDim3
            // 
            this.lblDim3.AutoSize = true;
            this.lblDim3.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim3.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim3.Location = new System.Drawing.Point(440, 279);
            this.lblDim3.Name = "lblDim3";
            this.lblDim3.Size = new System.Drawing.Size(20, 17);
            this.lblDim3.TabIndex = 12;
            this.lblDim3.Text = "M";
            // 
            // lblDim8
            // 
            this.lblDim8.AutoSize = true;
            this.lblDim8.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim8.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim8.Location = new System.Drawing.Point(735, 203);
            this.lblDim8.Name = "lblDim8";
            this.lblDim8.Size = new System.Drawing.Size(43, 17);
            this.lblDim8.TabIndex = 12;
            this.lblDim8.Text = "Milli-g";
            // 
            // lblDim2
            // 
            this.lblDim2.AutoSize = true;
            this.lblDim2.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim2.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim2.Location = new System.Drawing.Point(440, 242);
            this.lblDim2.Name = "lblDim2";
            this.lblDim2.Size = new System.Drawing.Size(29, 17);
            this.lblDim2.TabIndex = 12;
            this.lblDim2.Text = "kPa";
            // 
            // lblDim15
            // 
            this.lblDim15.AutoSize = true;
            this.lblDim15.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim15.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim15.Location = new System.Drawing.Point(440, 165);
            this.lblDim15.Name = "lblDim15";
            this.lblDim15.Size = new System.Drawing.Size(0, 17);
            this.lblDim15.TabIndex = 12;
            // 
            // lblDim1
            // 
            this.lblDim1.AutoSize = true;
            this.lblDim1.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDim1.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDim1.Location = new System.Drawing.Point(440, 205);
            this.lblDim1.Name = "lblDim1";
            this.lblDim1.Size = new System.Drawing.Size(20, 17);
            this.lblDim1.TabIndex = 12;
            this.lblDim1.Text = "°C";
            // 
            // lblCh15
            // 
            this.lblCh15.AutoSize = true;
            this.lblCh15.Location = new System.Drawing.Point(248, 142);
            this.lblCh15.Name = "lblCh15";
            this.lblCh15.Size = new System.Drawing.Size(69, 15);
            this.lblCh15.TabIndex = 12;
            this.lblCh15.Text = "Timestamp:";
            // 
            // lblCh1
            // 
            this.lblCh1.AutoSize = true;
            this.lblCh1.Location = new System.Drawing.Point(250, 202);
            this.lblCh1.Name = "lblCh1";
            this.lblCh1.Size = new System.Drawing.Size(66, 15);
            this.lblCh1.TabIndex = 12;
            this.lblCh1.Text = "Temp - Ext:";
            // 
            // lblCh2
            // 
            this.lblCh2.AutoSize = true;
            this.lblCh2.Location = new System.Drawing.Point(235, 239);
            this.lblCh2.Name = "lblCh2";
            this.lblCh2.Size = new System.Drawing.Size(81, 15);
            this.lblCh2.TabIndex = 12;
            this.lblCh2.Text = "Pressure - Ext:";
            // 
            // lblCh12
            // 
            this.lblCh12.AutoSize = true;
            this.lblCh12.Location = new System.Drawing.Point(496, 352);
            this.lblCh12.Name = "lblCh12";
            this.lblCh12.Size = new System.Drawing.Size(100, 15);
            this.lblCh12.TabIndex = 12;
            this.lblCh12.Text = "Magnetic - Force:";
            // 
            // lblCh11
            // 
            this.lblCh11.AutoSize = true;
            this.lblCh11.Location = new System.Drawing.Point(510, 314);
            this.lblCh11.Name = "lblCh11";
            this.lblCh11.Size = new System.Drawing.Size(86, 15);
            this.lblCh11.TabIndex = 12;
            this.lblCh11.Text = "Rotation - Roll:";
            // 
            // lblCh10
            // 
            this.lblCh10.AutoSize = true;
            this.lblCh10.Location = new System.Drawing.Point(503, 276);
            this.lblCh10.Name = "lblCh10";
            this.lblCh10.Size = new System.Drawing.Size(93, 15);
            this.lblCh10.TabIndex = 12;
            this.lblCh10.Text = "Rotation - Pitch:";
            // 
            // lblCh9
            // 
            this.lblCh9.AutoSize = true;
            this.lblCh9.Location = new System.Drawing.Point(521, 238);
            this.lblCh9.Name = "lblCh9";
            this.lblCh9.Size = new System.Drawing.Size(75, 15);
            this.lblCh9.TabIndex = 12;
            this.lblCh9.Text = "Light - Level:";
            // 
            // lblCh8
            // 
            this.lblCh8.AutoSize = true;
            this.lblCh8.Location = new System.Drawing.Point(521, 200);
            this.lblCh8.Name = "lblCh8";
            this.lblCh8.Size = new System.Drawing.Size(75, 15);
            this.lblCh8.TabIndex = 12;
            this.lblCh8.Text = "Accel - Total:";
            // 
            // lblRecording
            // 
            this.lblRecording.Location = new System.Drawing.Point(422, 126);
            this.lblRecording.Name = "lblRecording";
            this.lblRecording.Size = new System.Drawing.Size(113, 15);
            this.lblRecording.TabIndex = 11;
            this.lblRecording.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picRecord
            // 
            this.picRecord.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picRecord.Image = global::ESERO.CanSat.Properties.Resources.Recording;
            this.picRecord.Location = new System.Drawing.Point(422, 51);
            this.picRecord.Name = "picRecord";
            this.picRecord.Size = new System.Drawing.Size(113, 72);
            this.picRecord.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picRecord.TabIndex = 10;
            this.picRecord.TabStop = false;
            this.ttMain.SetToolTip(this.picRecord, "Start/Stop recording for export and analysis");
            this.picRecord.Click += new System.EventHandler(this.picRecord_Click);
            // 
            // chkAll
            // 
            this.chkAll.Border3DStyle = System.Windows.Forms.Border3DStyle.Flat;
            this.chkAll.BorderColor = System.Drawing.Color.White;
            this.chkAll.BorderSingle = System.Windows.Forms.ButtonBorderStyle.None;
            this.chkAll.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.chkAll.ForeColor = System.Drawing.Color.Chocolate;
            this.chkAll.GradientEnd = System.Drawing.Color.Red;
            this.chkAll.GradientStart = System.Drawing.Color.IndianRed;
            this.chkAll.Location = new System.Drawing.Point(251, 500);
            this.chkAll.Name = "chkAll";
            this.chkAll.Office2007ColorScheme = Syncfusion.Windows.Forms.Office2007Theme.Silver;
            this.chkAll.Size = new System.Drawing.Size(150, 21);
            this.chkAll.TabIndex = 8;
            this.chkAll.TabStop = false;
            this.chkAll.Text = "Check/Uncheck All";
            this.chkAll.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ttMain.SetToolTip(this.chkAll, "Check/Uncheck channels");
            this.chkAll.CheckStateChanged += new System.EventHandler(this.chkAll_CheckStateChanged);
            // 
            // glbl7
            // 
            this.glbl7.BeforeTouchSize = new System.Drawing.Size(102, 24);
            this.glbl7.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl7.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl7.Location = new System.Drawing.Point(332, 424);
            this.glbl7.Name = "glbl7";
            this.glbl7.Size = new System.Drawing.Size(102, 24);
            this.glbl7.TabIndex = 7;
            this.glbl7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // glbl6
            // 
            this.glbl6.BeforeTouchSize = new System.Drawing.Size(102, 24);
            this.glbl6.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl6.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl6.Location = new System.Drawing.Point(332, 387);
            this.glbl6.Name = "glbl6";
            this.glbl6.Size = new System.Drawing.Size(102, 24);
            this.glbl6.TabIndex = 7;
            this.glbl6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // glbl12
            // 
            this.glbl12.BeforeTouchSize = new System.Drawing.Size(102, 24);
            this.glbl12.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl12.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl12.Location = new System.Drawing.Point(617, 352);
            this.glbl12.Name = "glbl12";
            this.glbl12.Size = new System.Drawing.Size(102, 24);
            this.glbl12.TabIndex = 7;
            this.glbl12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // glbl5
            // 
            this.glbl5.BeforeTouchSize = new System.Drawing.Size(102, 24);
            this.glbl5.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl5.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl5.Location = new System.Drawing.Point(332, 350);
            this.glbl5.Name = "glbl5";
            this.glbl5.Size = new System.Drawing.Size(102, 24);
            this.glbl5.TabIndex = 7;
            this.glbl5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // glbl11
            // 
            this.glbl11.BeforeTouchSize = new System.Drawing.Size(102, 24);
            this.glbl11.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl11.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl11.Location = new System.Drawing.Point(617, 314);
            this.glbl11.Name = "glbl11";
            this.glbl11.Size = new System.Drawing.Size(102, 24);
            this.glbl11.TabIndex = 7;
            this.glbl11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // glbl4
            // 
            this.glbl4.BeforeTouchSize = new System.Drawing.Size(102, 24);
            this.glbl4.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl4.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl4.Location = new System.Drawing.Point(332, 313);
            this.glbl4.Name = "glbl4";
            this.glbl4.Size = new System.Drawing.Size(102, 24);
            this.glbl4.TabIndex = 7;
            this.glbl4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // glbl10
            // 
            this.glbl10.BeforeTouchSize = new System.Drawing.Size(102, 24);
            this.glbl10.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl10.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl10.Location = new System.Drawing.Point(617, 276);
            this.glbl10.Name = "glbl10";
            this.glbl10.Size = new System.Drawing.Size(102, 24);
            this.glbl10.TabIndex = 7;
            this.glbl10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // glbl3
            // 
            this.glbl3.BeforeTouchSize = new System.Drawing.Size(102, 24);
            this.glbl3.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl3.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl3.Location = new System.Drawing.Point(332, 276);
            this.glbl3.Name = "glbl3";
            this.glbl3.Size = new System.Drawing.Size(102, 24);
            this.glbl3.TabIndex = 7;
            this.glbl3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // glbl9
            // 
            this.glbl9.BeforeTouchSize = new System.Drawing.Size(102, 24);
            this.glbl9.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl9.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl9.Location = new System.Drawing.Point(617, 238);
            this.glbl9.Name = "glbl9";
            this.glbl9.Size = new System.Drawing.Size(102, 24);
            this.glbl9.TabIndex = 7;
            this.glbl9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // glbl8
            // 
            this.glbl8.BeforeTouchSize = new System.Drawing.Size(102, 24);
            this.glbl8.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl8.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl8.Location = new System.Drawing.Point(617, 200);
            this.glbl8.Name = "glbl8";
            this.glbl8.Size = new System.Drawing.Size(102, 24);
            this.glbl8.TabIndex = 7;
            this.glbl8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // glbl2
            // 
            this.glbl2.BeforeTouchSize = new System.Drawing.Size(102, 24);
            this.glbl2.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl2.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl2.Location = new System.Drawing.Point(332, 239);
            this.glbl2.Name = "glbl2";
            this.glbl2.Size = new System.Drawing.Size(102, 24);
            this.glbl2.TabIndex = 7;
            this.glbl2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // glbl15
            // 
            this.glbl15.BeforeTouchSize = new System.Drawing.Size(183, 24);
            this.glbl15.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl15.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl15.ForeColor = System.Drawing.Color.Maroon;
            this.glbl15.Location = new System.Drawing.Point(252, 165);
            this.glbl15.Name = "glbl15";
            this.glbl15.Size = new System.Drawing.Size(183, 24);
            this.glbl15.TabIndex = 7;
            this.glbl15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // glbl1
            // 
            this.glbl1.BeforeTouchSize = new System.Drawing.Size(102, 24);
            this.glbl1.BorderAppearance = System.Windows.Forms.BorderStyle.None;
            this.glbl1.BorderSides = ((System.Windows.Forms.Border3DSide)(((((System.Windows.Forms.Border3DSide.Left | System.Windows.Forms.Border3DSide.Top) 
            | System.Windows.Forms.Border3DSide.Right) 
            | System.Windows.Forms.Border3DSide.Bottom) 
            | System.Windows.Forms.Border3DSide.Middle)));
            this.glbl1.Location = new System.Drawing.Point(332, 202);
            this.glbl1.Name = "glbl1";
            this.glbl1.Size = new System.Drawing.Size(102, 24);
            this.glbl1.TabIndex = 7;
            this.glbl1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tgl6
            // 
            activeStateCollection1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            activeStateCollection1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(103)))), ((int)(((byte)(176)))));
            this.tgl6.ActiveState = activeStateCollection1;
            this.tgl6.DisplayMode = Syncfusion.Windows.Forms.Tools.DisplayType.Image;
            this.tgl6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tgl6.ForeColor = System.Drawing.Color.Black;
            inactiveStateCollection1.BackColor = System.Drawing.Color.White;
            inactiveStateCollection1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            inactiveStateCollection1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            inactiveStateCollection1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tgl6.InactiveState = inactiveStateCollection1;
            this.tgl6.Location = new System.Drawing.Point(128, 202);
            this.tgl6.MinimumSize = new System.Drawing.Size(52, 20);
            this.tgl6.Name = "tgl6";
            this.tgl6.Size = new System.Drawing.Size(52, 20);
            sliderCollection1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            sliderCollection1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection1.InactiveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            sliderCollection1.InactiveHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(94)))), ((int)(((byte)(94)))));
            this.tgl6.Slider = sliderCollection1;
            this.tgl6.TabIndex = 6;
            this.tgl6.ThemeName = "Office2016Colorful";
            this.tgl6.ToggleState = Syncfusion.Windows.Forms.Tools.ToggleButtonState.Active;
            this.tgl6.VisualStyle = Syncfusion.Windows.Forms.Tools.ToggleButtonStyle.Office2016Colorful;
            this.tgl6.ToggleStateChanged += new Syncfusion.Windows.Forms.Tools.ToggleStateChangedEventHandler(this.OnToggleStateChanged);
            // 
            // grpData4
            // 
            this.grpData4.BackColor = System.Drawing.Color.White;
            this.grpData4.Controls.Add(this.autoLabel15);
            this.grpData4.Controls.Add(this.autoLabel16);
            this.grpData4.Controls.Add(this.tgl14);
            this.grpData4.Controls.Add(this.tgl13);
            this.grpData4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.grpData4.ForeColor = System.Drawing.Color.Blue;
            this.grpData4.Location = new System.Drawing.Point(17, 438);
            this.grpData4.Name = "grpData4";
            this.grpData4.Size = new System.Drawing.Size(190, 83);
            this.grpData4.TabIndex = 2;
            this.grpData4.TabStop = false;
            this.grpData4.Text = "V2 Only";
            // 
            // autoLabel15
            // 
            this.autoLabel15.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.autoLabel15.Location = new System.Drawing.Point(62, 48);
            this.autoLabel15.Name = "autoLabel15";
            this.autoLabel15.Size = new System.Drawing.Size(44, 15);
            this.autoLabel15.TabIndex = 3;
            this.autoLabel15.Text = "Sound:";
            // 
            // autoLabel16
            // 
            this.autoLabel16.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.autoLabel16.Location = new System.Drawing.Point(64, 22);
            this.autoLabel16.Name = "autoLabel16";
            this.autoLabel16.Size = new System.Drawing.Size(42, 15);
            this.autoLabel16.TabIndex = 3;
            this.autoLabel16.Text = "Touch:";
            // 
            // tgl14
            // 
            activeStateCollection2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            activeStateCollection2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(103)))), ((int)(((byte)(176)))));
            this.tgl14.ActiveState = activeStateCollection2;
            this.tgl14.DisplayMode = Syncfusion.Windows.Forms.Tools.DisplayType.Image;
            this.tgl14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tgl14.ForeColor = System.Drawing.Color.Black;
            inactiveStateCollection2.BackColor = System.Drawing.Color.White;
            inactiveStateCollection2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            inactiveStateCollection2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            inactiveStateCollection2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tgl14.InactiveState = inactiveStateCollection2;
            this.tgl14.Location = new System.Drawing.Point(113, 48);
            this.tgl14.MinimumSize = new System.Drawing.Size(52, 20);
            this.tgl14.Name = "tgl14";
            this.tgl14.Size = new System.Drawing.Size(52, 20);
            sliderCollection2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            sliderCollection2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection2.InactiveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            sliderCollection2.InactiveHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(94)))), ((int)(((byte)(94)))));
            this.tgl14.Slider = sliderCollection2;
            this.tgl14.TabIndex = 6;
            this.tgl14.ThemeName = "Office2016Colorful";
            this.tgl14.ToggleState = Syncfusion.Windows.Forms.Tools.ToggleButtonState.Active;
            this.tgl14.VisualStyle = Syncfusion.Windows.Forms.Tools.ToggleButtonStyle.Office2016Colorful;
            this.tgl14.ToggleStateChanged += new Syncfusion.Windows.Forms.Tools.ToggleStateChangedEventHandler(this.OnToggleStateChanged);
            // 
            // tgl13
            // 
            activeStateCollection3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            activeStateCollection3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(103)))), ((int)(((byte)(176)))));
            this.tgl13.ActiveState = activeStateCollection3;
            this.tgl13.DisplayMode = Syncfusion.Windows.Forms.Tools.DisplayType.Image;
            this.tgl13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tgl13.ForeColor = System.Drawing.Color.Black;
            inactiveStateCollection3.BackColor = System.Drawing.Color.White;
            inactiveStateCollection3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            inactiveStateCollection3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            inactiveStateCollection3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tgl13.InactiveState = inactiveStateCollection3;
            this.tgl13.Location = new System.Drawing.Point(113, 22);
            this.tgl13.MinimumSize = new System.Drawing.Size(52, 20);
            this.tgl13.Name = "tgl13";
            this.tgl13.Size = new System.Drawing.Size(52, 20);
            sliderCollection3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            sliderCollection3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection3.InactiveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            sliderCollection3.InactiveHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(94)))), ((int)(((byte)(94)))));
            this.tgl13.Slider = sliderCollection3;
            this.tgl13.TabIndex = 6;
            this.tgl13.ThemeName = "Office2016Colorful";
            this.tgl13.ToggleState = Syncfusion.Windows.Forms.Tools.ToggleButtonState.Active;
            this.tgl13.VisualStyle = Syncfusion.Windows.Forms.Tools.ToggleButtonStyle.Office2016Colorful;
            this.tgl13.ToggleStateChanged += new Syncfusion.Windows.Forms.Tools.ToggleStateChangedEventHandler(this.OnToggleStateChanged);
            // 
            // grpData3
            // 
            this.grpData3.BackColor = System.Drawing.Color.White;
            this.grpData3.Controls.Add(this.tgl11);
            this.grpData3.Controls.Add(this.tgl10);
            this.grpData3.Controls.Add(this.tgl12);
            this.grpData3.Controls.Add(this.tgl9);
            this.grpData3.Controls.Add(this.autoLabel9);
            this.grpData3.Controls.Add(this.autoLabel10);
            this.grpData3.Controls.Add(this.autoLabel11);
            this.grpData3.Controls.Add(this.autoLabel12);
            this.grpData3.ForeColor = System.Drawing.Color.Blue;
            this.grpData3.Location = new System.Drawing.Point(17, 296);
            this.grpData3.Name = "grpData3";
            this.grpData3.Size = new System.Drawing.Size(190, 136);
            this.grpData3.TabIndex = 2;
            this.grpData3.TabStop = false;
            // 
            // tgl11
            // 
            activeStateCollection4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            activeStateCollection4.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(103)))), ((int)(((byte)(176)))));
            this.tgl11.ActiveState = activeStateCollection4;
            this.tgl11.DisplayMode = Syncfusion.Windows.Forms.Tools.DisplayType.Image;
            this.tgl11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tgl11.ForeColor = System.Drawing.Color.Black;
            inactiveStateCollection4.BackColor = System.Drawing.Color.White;
            inactiveStateCollection4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            inactiveStateCollection4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            inactiveStateCollection4.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tgl11.InactiveState = inactiveStateCollection4;
            this.tgl11.Location = new System.Drawing.Point(111, 74);
            this.tgl11.MinimumSize = new System.Drawing.Size(52, 20);
            this.tgl11.Name = "tgl11";
            this.tgl11.Size = new System.Drawing.Size(52, 20);
            sliderCollection4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            sliderCollection4.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection4.InactiveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            sliderCollection4.InactiveHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(94)))), ((int)(((byte)(94)))));
            this.tgl11.Slider = sliderCollection4;
            this.tgl11.TabIndex = 6;
            this.tgl11.ThemeName = "Office2016Colorful";
            this.tgl11.ToggleState = Syncfusion.Windows.Forms.Tools.ToggleButtonState.Active;
            this.tgl11.VisualStyle = Syncfusion.Windows.Forms.Tools.ToggleButtonStyle.Office2016Colorful;
            this.tgl11.ToggleStateChanged += new Syncfusion.Windows.Forms.Tools.ToggleStateChangedEventHandler(this.OnToggleStateChanged);
            // 
            // tgl10
            // 
            activeStateCollection5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            activeStateCollection5.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(103)))), ((int)(((byte)(176)))));
            this.tgl10.ActiveState = activeStateCollection5;
            this.tgl10.DisplayMode = Syncfusion.Windows.Forms.Tools.DisplayType.Image;
            this.tgl10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tgl10.ForeColor = System.Drawing.Color.Black;
            inactiveStateCollection5.BackColor = System.Drawing.Color.White;
            inactiveStateCollection5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            inactiveStateCollection5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            inactiveStateCollection5.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tgl10.InactiveState = inactiveStateCollection5;
            this.tgl10.Location = new System.Drawing.Point(111, 48);
            this.tgl10.MinimumSize = new System.Drawing.Size(52, 20);
            this.tgl10.Name = "tgl10";
            this.tgl10.Size = new System.Drawing.Size(52, 20);
            sliderCollection5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            sliderCollection5.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection5.InactiveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            sliderCollection5.InactiveHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(94)))), ((int)(((byte)(94)))));
            this.tgl10.Slider = sliderCollection5;
            this.tgl10.TabIndex = 6;
            this.tgl10.ThemeName = "Office2016Colorful";
            this.tgl10.ToggleState = Syncfusion.Windows.Forms.Tools.ToggleButtonState.Active;
            this.tgl10.VisualStyle = Syncfusion.Windows.Forms.Tools.ToggleButtonStyle.Office2016Colorful;
            this.tgl10.ToggleStateChanged += new Syncfusion.Windows.Forms.Tools.ToggleStateChangedEventHandler(this.OnToggleStateChanged);
            // 
            // tgl12
            // 
            activeStateCollection6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            activeStateCollection6.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(103)))), ((int)(((byte)(176)))));
            this.tgl12.ActiveState = activeStateCollection6;
            this.tgl12.DisplayMode = Syncfusion.Windows.Forms.Tools.DisplayType.Image;
            this.tgl12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tgl12.ForeColor = System.Drawing.Color.Black;
            inactiveStateCollection6.BackColor = System.Drawing.Color.White;
            inactiveStateCollection6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            inactiveStateCollection6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            inactiveStateCollection6.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tgl12.InactiveState = inactiveStateCollection6;
            this.tgl12.Location = new System.Drawing.Point(111, 100);
            this.tgl12.MinimumSize = new System.Drawing.Size(52, 20);
            this.tgl12.Name = "tgl12";
            this.tgl12.Size = new System.Drawing.Size(52, 20);
            sliderCollection6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            sliderCollection6.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection6.InactiveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            sliderCollection6.InactiveHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(94)))), ((int)(((byte)(94)))));
            this.tgl12.Slider = sliderCollection6;
            this.tgl12.TabIndex = 6;
            this.tgl12.ThemeName = "Office2016Colorful";
            this.tgl12.ToggleState = Syncfusion.Windows.Forms.Tools.ToggleButtonState.Active;
            this.tgl12.VisualStyle = Syncfusion.Windows.Forms.Tools.ToggleButtonStyle.Office2016Colorful;
            this.tgl12.ToggleStateChanged += new Syncfusion.Windows.Forms.Tools.ToggleStateChangedEventHandler(this.OnToggleStateChanged);
            // 
            // tgl9
            // 
            activeStateCollection7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            activeStateCollection7.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(103)))), ((int)(((byte)(176)))));
            this.tgl9.ActiveState = activeStateCollection7;
            this.tgl9.DisplayMode = Syncfusion.Windows.Forms.Tools.DisplayType.Image;
            this.tgl9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tgl9.ForeColor = System.Drawing.Color.Black;
            inactiveStateCollection7.BackColor = System.Drawing.Color.White;
            inactiveStateCollection7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            inactiveStateCollection7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            inactiveStateCollection7.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tgl9.InactiveState = inactiveStateCollection7;
            this.tgl9.Location = new System.Drawing.Point(111, 22);
            this.tgl9.MinimumSize = new System.Drawing.Size(52, 20);
            this.tgl9.Name = "tgl9";
            this.tgl9.Size = new System.Drawing.Size(52, 20);
            sliderCollection7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            sliderCollection7.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection7.InactiveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            sliderCollection7.InactiveHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(94)))), ((int)(((byte)(94)))));
            this.tgl9.Slider = sliderCollection7;
            this.tgl9.TabIndex = 6;
            this.tgl9.ThemeName = "Office2016Colorful";
            this.tgl9.ToggleState = Syncfusion.Windows.Forms.Tools.ToggleButtonState.Active;
            this.tgl9.VisualStyle = Syncfusion.Windows.Forms.Tools.ToggleButtonStyle.Office2016Colorful;
            this.tgl9.ToggleStateChanged += new Syncfusion.Windows.Forms.Tools.ToggleStateChangedEventHandler(this.OnToggleStateChanged);
            // 
            // autoLabel9
            // 
            this.autoLabel9.Location = new System.Drawing.Point(12, 100);
            this.autoLabel9.Name = "autoLabel9";
            this.autoLabel9.Size = new System.Drawing.Size(94, 15);
            this.autoLabel9.TabIndex = 3;
            this.autoLabel9.Text = "Magnetic-Force:";
            // 
            // autoLabel10
            // 
            this.autoLabel10.Location = new System.Drawing.Point(26, 74);
            this.autoLabel10.Name = "autoLabel10";
            this.autoLabel10.Size = new System.Drawing.Size(80, 15);
            this.autoLabel10.TabIndex = 3;
            this.autoLabel10.Text = "Rotation-Roll:";
            // 
            // autoLabel11
            // 
            this.autoLabel11.Location = new System.Drawing.Point(19, 48);
            this.autoLabel11.Name = "autoLabel11";
            this.autoLabel11.Size = new System.Drawing.Size(87, 15);
            this.autoLabel11.TabIndex = 3;
            this.autoLabel11.Text = "Rotation-Pitch:";
            // 
            // autoLabel12
            // 
            this.autoLabel12.Location = new System.Drawing.Point(37, 22);
            this.autoLabel12.Name = "autoLabel12";
            this.autoLabel12.Size = new System.Drawing.Size(69, 15);
            this.autoLabel12.TabIndex = 3;
            this.autoLabel12.Text = "Light-Level:";
            // 
            // grpData2
            // 
            this.grpData2.BackColor = System.Drawing.Color.White;
            this.grpData2.Controls.Add(this.tgl8);
            this.grpData2.Controls.Add(this.tgl5);
            this.grpData2.Controls.Add(this.tgl7);
            this.grpData2.Controls.Add(this.autoLabel5);
            this.grpData2.Controls.Add(this.autoLabel6);
            this.grpData2.Controls.Add(this.autoLabel7);
            this.grpData2.Controls.Add(this.autoLabel8);
            this.grpData2.ForeColor = System.Drawing.Color.Blue;
            this.grpData2.Location = new System.Drawing.Point(17, 154);
            this.grpData2.Name = "grpData2";
            this.grpData2.Size = new System.Drawing.Size(190, 136);
            this.grpData2.TabIndex = 2;
            this.grpData2.TabStop = false;
            // 
            // tgl8
            // 
            activeStateCollection8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            activeStateCollection8.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(103)))), ((int)(((byte)(176)))));
            this.tgl8.ActiveState = activeStateCollection8;
            this.tgl8.DisplayMode = Syncfusion.Windows.Forms.Tools.DisplayType.Image;
            this.tgl8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tgl8.ForeColor = System.Drawing.Color.Black;
            inactiveStateCollection8.BackColor = System.Drawing.Color.White;
            inactiveStateCollection8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            inactiveStateCollection8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            inactiveStateCollection8.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tgl8.InactiveState = inactiveStateCollection8;
            this.tgl8.Location = new System.Drawing.Point(111, 100);
            this.tgl8.MinimumSize = new System.Drawing.Size(52, 20);
            this.tgl8.Name = "tgl8";
            this.tgl8.Size = new System.Drawing.Size(52, 20);
            sliderCollection8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            sliderCollection8.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection8.InactiveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            sliderCollection8.InactiveHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(94)))), ((int)(((byte)(94)))));
            this.tgl8.Slider = sliderCollection8;
            this.tgl8.TabIndex = 6;
            this.tgl8.ThemeName = "Office2016Colorful";
            this.tgl8.ToggleState = Syncfusion.Windows.Forms.Tools.ToggleButtonState.Active;
            this.tgl8.VisualStyle = Syncfusion.Windows.Forms.Tools.ToggleButtonStyle.Office2016Colorful;
            this.tgl8.ToggleStateChanged += new Syncfusion.Windows.Forms.Tools.ToggleStateChangedEventHandler(this.OnToggleStateChanged);
            // 
            // tgl5
            // 
            activeStateCollection9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            activeStateCollection9.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(103)))), ((int)(((byte)(176)))));
            this.tgl5.ActiveState = activeStateCollection9;
            this.tgl5.DisplayMode = Syncfusion.Windows.Forms.Tools.DisplayType.Image;
            this.tgl5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tgl5.ForeColor = System.Drawing.Color.Black;
            inactiveStateCollection9.BackColor = System.Drawing.Color.White;
            inactiveStateCollection9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            inactiveStateCollection9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            inactiveStateCollection9.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tgl5.InactiveState = inactiveStateCollection9;
            this.tgl5.Location = new System.Drawing.Point(111, 22);
            this.tgl5.MinimumSize = new System.Drawing.Size(52, 20);
            this.tgl5.Name = "tgl5";
            this.tgl5.Size = new System.Drawing.Size(52, 20);
            sliderCollection9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            sliderCollection9.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection9.InactiveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            sliderCollection9.InactiveHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(94)))), ((int)(((byte)(94)))));
            this.tgl5.Slider = sliderCollection9;
            this.tgl5.TabIndex = 6;
            this.tgl5.ThemeName = "Office2016Colorful";
            this.tgl5.ToggleState = Syncfusion.Windows.Forms.Tools.ToggleButtonState.Active;
            this.tgl5.VisualStyle = Syncfusion.Windows.Forms.Tools.ToggleButtonStyle.Office2016Colorful;
            this.tgl5.ToggleStateChanged += new Syncfusion.Windows.Forms.Tools.ToggleStateChangedEventHandler(this.OnToggleStateChanged);
            // 
            // tgl7
            // 
            activeStateCollection10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            activeStateCollection10.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(103)))), ((int)(((byte)(176)))));
            this.tgl7.ActiveState = activeStateCollection10;
            this.tgl7.DisplayMode = Syncfusion.Windows.Forms.Tools.DisplayType.Image;
            this.tgl7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tgl7.ForeColor = System.Drawing.Color.Black;
            inactiveStateCollection10.BackColor = System.Drawing.Color.White;
            inactiveStateCollection10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            inactiveStateCollection10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            inactiveStateCollection10.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tgl7.InactiveState = inactiveStateCollection10;
            this.tgl7.Location = new System.Drawing.Point(111, 74);
            this.tgl7.MinimumSize = new System.Drawing.Size(52, 20);
            this.tgl7.Name = "tgl7";
            this.tgl7.Size = new System.Drawing.Size(52, 20);
            sliderCollection10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            sliderCollection10.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection10.InactiveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            sliderCollection10.InactiveHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(94)))), ((int)(((byte)(94)))));
            this.tgl7.Slider = sliderCollection10;
            this.tgl7.TabIndex = 6;
            this.tgl7.ThemeName = "Office2016Colorful";
            this.tgl7.ToggleState = Syncfusion.Windows.Forms.Tools.ToggleButtonState.Active;
            this.tgl7.VisualStyle = Syncfusion.Windows.Forms.Tools.ToggleButtonStyle.Office2016Colorful;
            this.tgl7.ToggleStateChanged += new Syncfusion.Windows.Forms.Tools.ToggleStateChangedEventHandler(this.OnToggleStateChanged);
            // 
            // autoLabel5
            // 
            this.autoLabel5.Location = new System.Drawing.Point(36, 100);
            this.autoLabel5.Name = "autoLabel5";
            this.autoLabel5.Size = new System.Drawing.Size(69, 15);
            this.autoLabel5.TabIndex = 3;
            this.autoLabel5.Text = "Accel-Total:";
            // 
            // autoLabel6
            // 
            this.autoLabel6.Location = new System.Drawing.Point(40, 74);
            this.autoLabel6.Name = "autoLabel6";
            this.autoLabel6.Size = new System.Drawing.Size(66, 15);
            this.autoLabel6.TabIndex = 3;
            this.autoLabel6.Text = "Accel-ZDir:";
            // 
            // autoLabel7
            // 
            this.autoLabel7.Location = new System.Drawing.Point(40, 48);
            this.autoLabel7.Name = "autoLabel7";
            this.autoLabel7.Size = new System.Drawing.Size(66, 15);
            this.autoLabel7.TabIndex = 3;
            this.autoLabel7.Text = "Accel-YDir:";
            // 
            // autoLabel8
            // 
            this.autoLabel8.Location = new System.Drawing.Point(40, 22);
            this.autoLabel8.Name = "autoLabel8";
            this.autoLabel8.Size = new System.Drawing.Size(66, 15);
            this.autoLabel8.TabIndex = 3;
            this.autoLabel8.Text = "Accel-XDir:";
            // 
            // grpData1
            // 
            this.grpData1.BackColor = System.Drawing.Color.White;
            this.grpData1.Controls.Add(this.tgl2);
            this.grpData1.Controls.Add(this.tgl4);
            this.grpData1.Controls.Add(this.tgl3);
            this.grpData1.Controls.Add(this.tgl1);
            this.grpData1.Controls.Add(this.autoLabel4);
            this.grpData1.Controls.Add(this.autoLabel3);
            this.grpData1.Controls.Add(this.autoLabel2);
            this.grpData1.Controls.Add(this.autoLabel1);
            this.grpData1.ForeColor = System.Drawing.Color.Blue;
            this.grpData1.Location = new System.Drawing.Point(17, 12);
            this.grpData1.Name = "grpData1";
            this.grpData1.Size = new System.Drawing.Size(190, 136);
            this.grpData1.TabIndex = 2;
            this.grpData1.TabStop = false;
            // 
            // tgl2
            // 
            activeStateCollection11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            activeStateCollection11.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(103)))), ((int)(((byte)(176)))));
            this.tgl2.ActiveState = activeStateCollection11;
            this.tgl2.DisplayMode = Syncfusion.Windows.Forms.Tools.DisplayType.Image;
            this.tgl2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tgl2.ForeColor = System.Drawing.Color.Black;
            inactiveStateCollection11.BackColor = System.Drawing.Color.White;
            inactiveStateCollection11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            inactiveStateCollection11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            inactiveStateCollection11.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tgl2.InactiveState = inactiveStateCollection11;
            this.tgl2.Location = new System.Drawing.Point(113, 48);
            this.tgl2.MinimumSize = new System.Drawing.Size(52, 20);
            this.tgl2.Name = "tgl2";
            this.tgl2.Size = new System.Drawing.Size(52, 20);
            sliderCollection11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            sliderCollection11.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection11.InactiveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            sliderCollection11.InactiveHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(94)))), ((int)(((byte)(94)))));
            this.tgl2.Slider = sliderCollection11;
            this.tgl2.TabIndex = 6;
            this.tgl2.ThemeName = "Office2016Colorful";
            this.tgl2.ToggleState = Syncfusion.Windows.Forms.Tools.ToggleButtonState.Active;
            this.tgl2.VisualStyle = Syncfusion.Windows.Forms.Tools.ToggleButtonStyle.Office2016Colorful;
            this.tgl2.ToggleStateChanged += new Syncfusion.Windows.Forms.Tools.ToggleStateChangedEventHandler(this.OnToggleStateChanged);
            // 
            // tgl4
            // 
            activeStateCollection12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            activeStateCollection12.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(103)))), ((int)(((byte)(176)))));
            this.tgl4.ActiveState = activeStateCollection12;
            this.tgl4.DisplayMode = Syncfusion.Windows.Forms.Tools.DisplayType.Image;
            this.tgl4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tgl4.ForeColor = System.Drawing.Color.Black;
            inactiveStateCollection12.BackColor = System.Drawing.Color.White;
            inactiveStateCollection12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            inactiveStateCollection12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            inactiveStateCollection12.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tgl4.InactiveState = inactiveStateCollection12;
            this.tgl4.Location = new System.Drawing.Point(113, 100);
            this.tgl4.MinimumSize = new System.Drawing.Size(52, 20);
            this.tgl4.Name = "tgl4";
            this.tgl4.Size = new System.Drawing.Size(52, 20);
            sliderCollection12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            sliderCollection12.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection12.InactiveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            sliderCollection12.InactiveHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(94)))), ((int)(((byte)(94)))));
            this.tgl4.Slider = sliderCollection12;
            this.tgl4.TabIndex = 6;
            this.tgl4.ThemeName = "Office2016Colorful";
            this.tgl4.ToggleState = Syncfusion.Windows.Forms.Tools.ToggleButtonState.Active;
            this.tgl4.VisualStyle = Syncfusion.Windows.Forms.Tools.ToggleButtonStyle.Office2016Colorful;
            this.tgl4.ToggleStateChanged += new Syncfusion.Windows.Forms.Tools.ToggleStateChangedEventHandler(this.OnToggleStateChanged);
            // 
            // tgl3
            // 
            activeStateCollection13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            activeStateCollection13.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(103)))), ((int)(((byte)(176)))));
            this.tgl3.ActiveState = activeStateCollection13;
            this.tgl3.DisplayMode = Syncfusion.Windows.Forms.Tools.DisplayType.Image;
            this.tgl3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tgl3.ForeColor = System.Drawing.Color.Black;
            inactiveStateCollection13.BackColor = System.Drawing.Color.White;
            inactiveStateCollection13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            inactiveStateCollection13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            inactiveStateCollection13.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tgl3.InactiveState = inactiveStateCollection13;
            this.tgl3.Location = new System.Drawing.Point(113, 74);
            this.tgl3.MinimumSize = new System.Drawing.Size(52, 20);
            this.tgl3.Name = "tgl3";
            this.tgl3.Size = new System.Drawing.Size(52, 20);
            sliderCollection13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            sliderCollection13.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection13.InactiveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            sliderCollection13.InactiveHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(94)))), ((int)(((byte)(94)))));
            this.tgl3.Slider = sliderCollection13;
            this.tgl3.TabIndex = 6;
            this.tgl3.ThemeName = "Office2016Colorful";
            this.tgl3.ToggleState = Syncfusion.Windows.Forms.Tools.ToggleButtonState.Active;
            this.tgl3.VisualStyle = Syncfusion.Windows.Forms.Tools.ToggleButtonStyle.Office2016Colorful;
            this.tgl3.ToggleStateChanged += new Syncfusion.Windows.Forms.Tools.ToggleStateChangedEventHandler(this.OnToggleStateChanged);
            // 
            // tgl1
            // 
            activeStateCollection14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(115)))), ((int)(((byte)(199)))));
            activeStateCollection14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            activeStateCollection14.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(103)))), ((int)(((byte)(176)))));
            this.tgl1.ActiveState = activeStateCollection14;
            this.tgl1.DisplayMode = Syncfusion.Windows.Forms.Tools.DisplayType.Image;
            this.tgl1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tgl1.ForeColor = System.Drawing.Color.Black;
            inactiveStateCollection14.BackColor = System.Drawing.Color.White;
            inactiveStateCollection14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            inactiveStateCollection14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            inactiveStateCollection14.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tgl1.InactiveState = inactiveStateCollection14;
            this.tgl1.Location = new System.Drawing.Point(113, 22);
            this.tgl1.MinimumSize = new System.Drawing.Size(52, 20);
            this.tgl1.Name = "tgl1";
            this.tgl1.Size = new System.Drawing.Size(52, 20);
            sliderCollection14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            sliderCollection14.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            sliderCollection14.InactiveBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            sliderCollection14.InactiveHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(94)))), ((int)(((byte)(94)))));
            this.tgl1.Slider = sliderCollection14;
            this.tgl1.TabIndex = 6;
            this.tgl1.ThemeName = "Office2016Colorful";
            this.tgl1.ToggleState = Syncfusion.Windows.Forms.Tools.ToggleButtonState.Active;
            this.tgl1.VisualStyle = Syncfusion.Windows.Forms.Tools.ToggleButtonStyle.Office2016Colorful;
            this.tgl1.ToggleStateChanged += new Syncfusion.Windows.Forms.Tools.ToggleStateChangedEventHandler(this.OnToggleStateChanged);
            // 
            // autoLabel4
            // 
            this.autoLabel4.Location = new System.Drawing.Point(48, 100);
            this.autoLabel4.Name = "autoLabel4";
            this.autoLabel4.Size = new System.Drawing.Size(58, 15);
            this.autoLabel4.TabIndex = 3;
            this.autoLabel4.Text = "Temp-Int:";
            // 
            // autoLabel3
            // 
            this.autoLabel3.Location = new System.Drawing.Point(53, 74);
            this.autoLabel3.Name = "autoLabel3";
            this.autoLabel3.Size = new System.Drawing.Size(52, 15);
            this.autoLabel3.TabIndex = 3;
            this.autoLabel3.Text = "Altitude:";
            // 
            // autoLabel2
            // 
            this.autoLabel2.Location = new System.Drawing.Point(31, 48);
            this.autoLabel2.Name = "autoLabel2";
            this.autoLabel2.Size = new System.Drawing.Size(75, 15);
            this.autoLabel2.TabIndex = 3;
            this.autoLabel2.Text = "Pressure-Ext:";
            // 
            // autoLabel1
            // 
            this.autoLabel1.Location = new System.Drawing.Point(46, 22);
            this.autoLabel1.Name = "autoLabel1";
            this.autoLabel1.Size = new System.Drawing.Size(60, 15);
            this.autoLabel1.TabIndex = 3;
            this.autoLabel1.Text = "Temp-Ext:";
            // 
            // pnlA
            // 
            this.pnlA.Border3DStyle = System.Windows.Forms.Border3DStyle.Flat;
            this.pnlA.BorderColor = System.Drawing.Color.Transparent;
            this.pnlA.BorderSingle = System.Windows.Forms.ButtonBorderStyle.None;
            this.pnlA.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pnlA.Controls.Add(this.lbl5);
            this.pnlA.Controls.Add(this.lbl4);
            this.pnlA.Controls.Add(this.lbl3);
            this.pnlA.Controls.Add(this.lbl2);
            this.pnlA.Controls.Add(this.lbl1);
            this.pnlA.Controls.Add(this.txtSpeed);
            this.pnlA.Controls.Add(this.txtPortAttributes);
            this.pnlA.Controls.Add(this.txtRawData);
            this.pnlA.Controls.Add(this.txtVersion);
            this.pnlA.Controls.Add(this.txtConnected);
            this.pnlA.Location = new System.Drawing.Point(443, 40);
            this.pnlA.Name = "pnlA";
            this.pnlA.Size = new System.Drawing.Size(620, 371);
            this.pnlA.TabIndex = 4;
            this.pnlA.Visible = false;
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl5.ForeColor = System.Drawing.Color.Maroon;
            this.lbl5.Location = new System.Drawing.Point(22, 332);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(120, 14);
            this.lbl5.TabIndex = 2;
            this.lbl5.Text = "Transmission speed:";
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl4.ForeColor = System.Drawing.Color.Maroon;
            this.lbl4.Location = new System.Drawing.Point(22, 282);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(31, 14);
            this.lbl4.TabIndex = 2;
            this.lbl4.Text = "Port:";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl3.ForeColor = System.Drawing.Color.Maroon;
            this.lbl3.Location = new System.Drawing.Point(22, 232);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(111, 14);
            this.lbl3.TabIndex = 2;
            this.lbl3.Text = "Raw Data received:";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl2.ForeColor = System.Drawing.Color.Maroon;
            this.lbl2.Location = new System.Drawing.Point(22, 183);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(55, 14);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "MicroBit:";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl1.ForeColor = System.Drawing.Color.Maroon;
            this.lbl1.Location = new System.Drawing.Point(22, 136);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(107, 14);
            this.lbl1.TabIndex = 2;
            this.lbl1.Text = "Connection status:";
            // 
            // txtSpeed
            // 
            this.txtSpeed.BackColor = System.Drawing.Color.White;
            this.txtSpeed.BeforeTouchSize = new System.Drawing.Size(141, 15);
            this.txtSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSpeed.Location = new System.Drawing.Point(175, 332);
            this.txtSpeed.Name = "txtSpeed";
            this.txtSpeed.ReadOnly = true;
            this.txtSpeed.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSpeed.Size = new System.Drawing.Size(476, 16);
            this.txtSpeed.TabIndex = 1;
            this.txtSpeed.TabStop = false;
            // 
            // txtPortAttributes
            // 
            this.txtPortAttributes.BackColor = System.Drawing.Color.White;
            this.txtPortAttributes.BeforeTouchSize = new System.Drawing.Size(141, 15);
            this.txtPortAttributes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPortAttributes.Location = new System.Drawing.Point(175, 282);
            this.txtPortAttributes.Name = "txtPortAttributes";
            this.txtPortAttributes.ReadOnly = true;
            this.txtPortAttributes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPortAttributes.Size = new System.Drawing.Size(476, 16);
            this.txtPortAttributes.TabIndex = 1;
            this.txtPortAttributes.TabStop = false;
            // 
            // txtRawData
            // 
            this.txtRawData.BackColor = System.Drawing.Color.White;
            this.txtRawData.BeforeTouchSize = new System.Drawing.Size(141, 15);
            this.txtRawData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRawData.Location = new System.Drawing.Point(175, 232);
            this.txtRawData.Name = "txtRawData";
            this.txtRawData.ReadOnly = true;
            this.txtRawData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRawData.Size = new System.Drawing.Size(476, 16);
            this.txtRawData.TabIndex = 1;
            this.txtRawData.TabStop = false;
            // 
            // txtVersion
            // 
            this.txtVersion.BackColor = System.Drawing.Color.White;
            this.txtVersion.BeforeTouchSize = new System.Drawing.Size(141, 15);
            this.txtVersion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVersion.Location = new System.Drawing.Point(175, 183);
            this.txtVersion.Name = "txtVersion";
            this.txtVersion.ReadOnly = true;
            this.txtVersion.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtVersion.Size = new System.Drawing.Size(476, 16);
            this.txtVersion.TabIndex = 1;
            this.txtVersion.TabStop = false;
            // 
            // txtConnected
            // 
            this.txtConnected.BackColor = System.Drawing.Color.White;
            this.txtConnected.BeforeTouchSize = new System.Drawing.Size(141, 15);
            this.txtConnected.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtConnected.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtConnected.ForeColor = System.Drawing.Color.Black;
            this.txtConnected.Location = new System.Drawing.Point(175, 136);
            this.txtConnected.Name = "txtConnected";
            this.txtConnected.ReadOnly = true;
            this.txtConnected.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtConnected.Size = new System.Drawing.Size(141, 15);
            this.txtConnected.TabIndex = 1;
            this.txtConnected.TabStop = false;
            this.txtConnected.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlC
            // 
            this.pnlC.Border3DStyle = System.Windows.Forms.Border3DStyle.Flat;
            this.pnlC.BorderColor = System.Drawing.Color.Transparent;
            this.pnlC.BorderSingle = System.Windows.Forms.ButtonBorderStyle.None;
            this.pnlC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pnlC.Location = new System.Drawing.Point(540, 5);
            this.pnlC.Name = "pnlC";
            this.pnlC.Size = new System.Drawing.Size(91, 29);
            this.pnlC.TabIndex = 5;
            this.pnlC.Visible = false;
            // 
            // fMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.CaptionBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.CaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CaptionForeColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1074, 532);
            this.Controls.Add(this.pnlB);
            this.Controls.Add(this.pnlA);
            this.Controls.Add(this.pnlC);
            this.Controls.Add(this.pnlMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "fMain";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ESERO - CanSat";
            this.Load += new System.EventHandler(this.frmMockup_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pnlMenu)).EndInit();
            this.pnlMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlB)).EndInit();
            this.pnlB.ResumeLayout(false);
            this.pnlB.PerformLayout();
            this.grpData5.ResumeLayout(false);
            this.grpData5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRecord)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAll)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl6)).EndInit();
            this.grpData4.ResumeLayout(false);
            this.grpData4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tgl14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl13)).EndInit();
            this.grpData3.ResumeLayout(false);
            this.grpData3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tgl11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl9)).EndInit();
            this.grpData2.ResumeLayout(false);
            this.grpData2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tgl8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl7)).EndInit();
            this.grpData1.ResumeLayout(false);
            this.grpData1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tgl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tgl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlA)).EndInit();
            this.pnlA.ResumeLayout(false);
            this.pnlA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSpeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPortAttributes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRawData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVersion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtConnected)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlC)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Syncfusion.Windows.Forms.Tools.GradientPanel pnlMenu;
        private System.Windows.Forms.PictureBox picA;
        private System.Windows.Forms.PictureBox pbxTop;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox picB;
        private Syncfusion.Windows.Forms.Tools.toolstripitem btnOpenPort;
        private Syncfusion.Windows.Forms.Tools.toolstripitem btnViewTraffic;
        private Syncfusion.Windows.Forms.Tools.GradientPanel pnlB;
        private Syncfusion.Windows.Forms.Tools.GradientPanel pnlA;
        private System.Windows.Forms.GroupBox grpData1;
        private Syncfusion.Windows.Forms.Tools.AutoLabel autoLabel2;
        private Syncfusion.Windows.Forms.Tools.AutoLabel autoLabel1;
        private Syncfusion.Windows.Forms.Tools.AutoLabel autoLabel4;
        private Syncfusion.Windows.Forms.Tools.AutoLabel autoLabel3;
        private System.Windows.Forms.GroupBox grpData2;
        private Syncfusion.Windows.Forms.Tools.AutoLabel autoLabel5;
        private Syncfusion.Windows.Forms.Tools.AutoLabel autoLabel6;
        private Syncfusion.Windows.Forms.Tools.AutoLabel autoLabel7;
        private Syncfusion.Windows.Forms.Tools.AutoLabel autoLabel8;
        private System.Windows.Forms.GroupBox grpData3;
        private Syncfusion.Windows.Forms.Tools.AutoLabel autoLabel9;
        private Syncfusion.Windows.Forms.Tools.AutoLabel autoLabel10;
        private Syncfusion.Windows.Forms.Tools.AutoLabel autoLabel11;
        private Syncfusion.Windows.Forms.Tools.AutoLabel autoLabel12;
        private System.Windows.Forms.GroupBox grpData4;
        private Syncfusion.Windows.Forms.Tools.AutoLabel autoLabel15;
        private Syncfusion.Windows.Forms.Tools.AutoLabel autoLabel16;
        private System.Windows.Forms.Button btnSerialPort;
        private System.Windows.Forms.Button btnSelectChannels;
        private System.Windows.Forms.Button btnAbout;
        private System.Windows.Forms.PictureBox picC;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Button btnGraphs;
        private System.Windows.Forms.PictureBox picE;
        private System.Windows.Forms.PictureBox picD;
        private Syncfusion.Windows.Forms.Tools.ToggleButton tgl6;
        private Syncfusion.Windows.Forms.Tools.ToggleButton tgl14;
        private Syncfusion.Windows.Forms.Tools.ToggleButton tgl13;
        private Syncfusion.Windows.Forms.Tools.ToggleButton tgl11;
        private Syncfusion.Windows.Forms.Tools.ToggleButton tgl10;
        private Syncfusion.Windows.Forms.Tools.ToggleButton tgl12;
        private Syncfusion.Windows.Forms.Tools.ToggleButton tgl9;
        private Syncfusion.Windows.Forms.Tools.ToggleButton tgl8;
        private Syncfusion.Windows.Forms.Tools.ToggleButton tgl5;
        private Syncfusion.Windows.Forms.Tools.ToggleButton tgl7;
        private Syncfusion.Windows.Forms.Tools.ToggleButton tgl2;
        private Syncfusion.Windows.Forms.Tools.ToggleButton tgl4;
        private Syncfusion.Windows.Forms.Tools.ToggleButton tgl3;
        private Syncfusion.Windows.Forms.Tools.ToggleButton tgl1;
        private Syncfusion.Windows.Forms.Tools.GradientPanel pnlC;
        // Public controls
        public Syncfusion.Windows.Forms.Tools.TextBoxExt txtConnected;
        public Syncfusion.Windows.Forms.Tools.TextBoxExt txtRawData;
        public Syncfusion.Windows.Forms.Tools.TextBoxExt txtVersion;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl1;
        private Syncfusion.Windows.Forms.SfToolTip ttMain;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl14;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl7;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl13;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl6;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl12;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl5;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl11;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl4;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl10;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl3;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl9;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl8;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl2;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl1;
        private Syncfusion.Windows.Forms.Tools.CheckBoxAdv chkAll;
        private System.Windows.Forms.PictureBox picRecord;
        private System.Windows.Forms.Label lblRecording;
        private System.Windows.Forms.Label lblCh7;
        private System.Windows.Forms.Label lblCh6;
        private System.Windows.Forms.Label lblCh5;
        private System.Windows.Forms.Label lblCh4;
        private System.Windows.Forms.Label lblCh3;
        private System.Windows.Forms.Label lblCh15;
        private System.Windows.Forms.Label lblCh1;
        private System.Windows.Forms.Label lblCh2;
        private System.Windows.Forms.Label lblCh14;
        private System.Windows.Forms.Label lblCh13;
        private System.Windows.Forms.Label lblCh12;
        private System.Windows.Forms.Label lblCh11;
        private System.Windows.Forms.Label lblCh10;
        private System.Windows.Forms.Label lblCh9;
        private System.Windows.Forms.Label lblCh8;
        private System.Windows.Forms.Label lblDim14;
        private System.Windows.Forms.Label lblDim7;
        private System.Windows.Forms.Label lblDim13;
        private System.Windows.Forms.Label lblDim6;
        private System.Windows.Forms.Label lblDim12;
        private System.Windows.Forms.Label lblDim5;
        private System.Windows.Forms.Label lblDim11;
        private System.Windows.Forms.Label lblDim10;
        private System.Windows.Forms.Label lblDim4;
        private System.Windows.Forms.Label lblDim9;
        private System.Windows.Forms.Label lblDim3;
        private System.Windows.Forms.Label lblDim8;
        private System.Windows.Forms.Label lblDim2;
        private System.Windows.Forms.Label lblDim1;
        private System.Windows.Forms.Label lblDim15;
        private Syncfusion.Windows.Forms.Tools.GradientLabel glbl15;
        private System.Windows.Forms.GroupBox grpData5;
        private System.Windows.Forms.OpenFileDialog dlgOpenFile;
        private System.Windows.Forms.Label lbl4;
        public Syncfusion.Windows.Forms.Tools.TextBoxExt txtPortAttributes;
        private System.Windows.Forms.Label lbl5;
        public Syncfusion.Windows.Forms.Tools.TextBoxExt txtSpeed;
    }
}